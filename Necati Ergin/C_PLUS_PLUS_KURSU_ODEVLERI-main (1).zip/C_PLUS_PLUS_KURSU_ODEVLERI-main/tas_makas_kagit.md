**Taş - Kağıt - Makas** iki kişi ile oynanan bir oyundur. 

Oyuncular aynı anda elini açarak bir sembol gösterir:
- Yumruk => Taş
- Açık el => Kağıt
- İşaret ve orta parmağın gösterilmesi => Makas

Kazanan aşağıdaki kurallara göre belirlenir:
- kağıt taşı yener (örter).
- taş makası yener (kırar).
- makas kağıdı yener (keser).

Bilgisayar ve gerçek bir oyuncu arasında Taş-Makas-Kağıt oynayan bir C++ programı yazınız. <br>
Oyuncu oyundan çıkmadan önce oyunu n kez oynayabilmelidir.
